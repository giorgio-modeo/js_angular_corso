var totale = 0;
var a = 5;

function saluta() {
    console.log('ciao');
}
function addizzione(a,b) {
    return a + b;
    
}
function sottrazzione() {
    return a-b
}
console.log(addizzione(a,7));
saluta();
console.log(sottrazzione(a,7));