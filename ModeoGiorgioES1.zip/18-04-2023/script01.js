'use strict';
// commento su una riga 
/*
commento 
multi linea
*/

var VecchiaManiera = 'ancora funziona';
let NuovaManiera = 'variabile con scope';
const iva =0.22;

//iva = 'pippo'
console.log(typeof VecchiaManiera);